package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.model.Book;
import com.cg.model.Library;
import com.cg.service.LibService;



@Controller
public class MainController {
	
	@Autowired
	LibService libservice;
	
	
	@RequestMapping("/")
	public String index()
	{
		System.out.println("index");
		return "index.jsp";
	}
	
        @RequestMapping(value="/addBook",method=RequestMethod.POST)
	public ModelAndView addBook(Library library,Book book)
	{			
		ModelAndView mav=new ModelAndView("Add.jsp");
		book.setLibrary(library);
		library.getBook().add(book);	
		Library lib1=libservice.add(library);
		mav.addObject(lib1);
		return mav;
		
	}
   
        @RequestMapping(value="/searchBook",method=RequestMethod.GET)
	public ModelAndView searchBook(@RequestParam int libraryId,@RequestParam int bookId) 
	{
		ModelAndView mav=new ModelAndView("Search.jsp");
		Library library=libservice.findBook(libraryId);
		Book book=libservice.getBookbyId(bookId);
		mav.addObject(library);
		mav.addObject(book);
		return mav;
	}
	
	@RequestMapping(value="/deleteBook",method=RequestMethod.GET)
	public String deleteBook(@RequestParam int libraryId) 
	{
		libservice.deleteBook(libraryId);
		return "Delete.jsp";
	}
	
	@RequestMapping(value="/updateBook",method=RequestMethod.POST)
	public ModelAndView updateBook(@RequestParam int bookId,@RequestParam String bookName,@RequestParam String author,@RequestParam String publisher) 
	{
		ModelAndView mav=new ModelAndView("Update.jsp");
		Book book=libservice.updateBookData(bookId,bookName,author,publisher);
		mav.addObject(book);
		return mav;
	}
	
}
