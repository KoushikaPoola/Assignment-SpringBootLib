package com.cg.repository;

import org.springframework.data.repository.CrudRepository;

import com.cg.model.Book;

public interface BookRepo extends CrudRepository<Book , Integer>{

}
