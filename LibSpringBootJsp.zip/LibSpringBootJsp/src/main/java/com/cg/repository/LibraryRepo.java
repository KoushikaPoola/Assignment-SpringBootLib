package com.cg.repository;


import org.springframework.data.repository.CrudRepository;

import com.cg.model.Library;

public interface LibraryRepo extends CrudRepository<Library , Integer>{

}
