package com.cg.service;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.model.Book;
import com.cg.model.Library;
import com.cg.repository.BookRepo;
import com.cg.repository.LibraryRepo;

@Service
public class LibService {
	
	@Autowired
	LibraryRepo librepo;
	
	@Autowired
	BookRepo bookrepo;
	
	public Library add(Library library)
	{
		return librepo.save(library);
		
	}
	
	public void deleteBook(Integer libraryId)
	{
		Library li =findBook(libraryId);
		librepo.delete(li);
	}

	public Library findBook(Integer libraryId) { 
		
		Optional<Library> optional =librepo.findById(libraryId);
		Library library=optional.get();
		return library;
		
	}
	
        public Book getBookbyId(Integer bookId) { 
		
                Optional<Book> optional =bookrepo.findById(bookId);
		Book book=optional.get();
		return book;
						
        }

        public Book updateBookData(int nwId, String nwName, String nwauth, String nwpubli) {
	// TODO Auto-generated method stub
	
	Book bo =getBookbyId(nwId);
	bo.setBookName(nwName);
	bo.setAuthor(nwauth);
	bo.setPublisher(nwpubli);
	bookrepo.save(bo);
	return bo;
}

}